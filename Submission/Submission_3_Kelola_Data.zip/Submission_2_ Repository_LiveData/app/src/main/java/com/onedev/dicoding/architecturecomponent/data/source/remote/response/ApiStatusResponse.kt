package com.onedev.dicoding.architecturecomponent.data.source.remote.response

enum class ApiStatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}