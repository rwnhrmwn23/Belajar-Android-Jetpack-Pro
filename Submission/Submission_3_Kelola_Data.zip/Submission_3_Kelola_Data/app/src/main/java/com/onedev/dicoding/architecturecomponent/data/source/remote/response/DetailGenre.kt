package com.onedev.dicoding.architecturecomponent.data.source.remote.response

data class DetailGenre(
    val id: Int,
    val name: String
)