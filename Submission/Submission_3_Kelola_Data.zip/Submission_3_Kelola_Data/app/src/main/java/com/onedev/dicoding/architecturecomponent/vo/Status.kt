package com.onedev.dicoding.architecturecomponent.vo

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}